<div class="modal fade" id="large-Modal-viewStudent" tabindex="-1"
role="dialog">
<div class="modal-dialog modal-lg" role="document">
<div class="modal-content">
    <div class="modal-header">
        <h4 class="modal-title">Osotech New Payment Entry</h4>
        <button type="button" class="close"
            data-dismiss="modal"
            aria-label="Close">
            <span
                aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="modal-body">
               <form>
                   
                    <div class="col-md-12">
                         <center>    <div class="col-md-12">
                            <div class="form-group">
                                <div id="img">
                                    
                                </div>
      
                            </div>
                        </div></center>
                    <div class="row">
                   
          
         <div class="col-md-6">
            <div class="form-group">
                <label>Admission No</label>
                <input type="text" name="" class="form-control" disabled="disabled" value="00012">
            </div>
            </div>
         <div class="col-md-6">
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" id="fulname" class="form-control" disabled="disabled">
            </div>
            </div>

         <div class="col-md-6">
            <div class="form-group">
                <label> Payee Current Class</label>
                <input type="text" id="current_class" class="form-control" disabled="disabled">
            </div>
            </div>
            <div class="col-md-6">
            <div class="form-group">
                <label> Parents Name</label>
                <input type="text" id="parent_name" class="form-control" disabled="disabled">
            </div>
            </div>
            <div class="col-md-6">
            <div class="form-group">
                <label> Parents' Phone</label>
                <input type="text" id="parent_phone" class="form-control" disabled="disabled" value="JSS1">
            </div>
            </div>
         
         
            <div class="col-md-6">
            <div class="form-group">
                <label> Default School fee</label>
                <input type="text" name="" class="form-control" disabled="disabled" value="JSS1">
            </div>
            </div>
            <div class="col-md-6">
            <div class="form-group">
                <label> Last Payment Amount</label>
                <input type="text" name="" class="form-control" disabled="disabled" value="JSS1">
            </div>
            </div>
        
         
           <div class="col-md-6">
            <div class="form-group">
                <label>Last Payment Date</label>
               <input type="text" class="form-control" placeholder="08-08-2021" disabled>
            </div>
            </div>

             <div class="col-md-6">
            <div class="form-group">
                <label>Payment Session</label>
               <input type="text" class="form-control" placeholder="2021-2022" disabled>
            </div>
            </div>

              <div class="col-md-6">
            <div class="form-group">
                <label>Due Balance</label>
                <input type="text" name="" class="form-control form-control-success" placeholder="Due Balance" disabled>
            </div>
            </div>
               </div>
                </div>
       </form>
       
    
    </div>
    <div class="modal-footer">
        <button type="button"
            class="btn btn-default waves-effect "
            data-dismiss="modal">Close</button>
        <!-- <button type="button"
            class="btn btn-primary waves-effect waves-light ">Save
            changes</button> -->
    </div>
</div>
</div>
</div>
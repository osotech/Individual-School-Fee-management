<?php 

echo '<div class="alert alert-warning alert-dismissible fade show mt-3" role="alert">
  <strong> WARNING!</strong> Feature not supported in this version of ISFMS. <b class="text-info"> <small> Upgrade to Premium Version</small></b>
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times;</span>
  </button>
</div>';

?>
 <nav class="pcoded-navbar">
                        <div class="pcoded-inner-navbar main-menu">
                            <div class="pcoded-navigatio-lavel">Navigation</div>
                            <ul class="pcoded-item pcoded-left-item">
                                <li class="pcoded-hasmenu active pcoded-trigger">
                                    <a href="javascript:void(0)">
                                        <span class="pcoded-micon"><i class="feather icon-home"></i></span>
                                        <span class="pcoded-mtext"> Dashboard</span>
                                    </a>
                                    <ul class="pcoded-submenu">
                                         
                                        <li class="">
                                            <a href="dt-advance.php">
                                                <span class="pcoded-mtext"> Payment Module</span>
                                            </a>
                                        </li>
                                       
                                        <li class=" ">
                                            <a href="student-registration.php">
                                                <span class="pcoded-mtext">Register Student</span>
                                            </a>
                                        </li>
                                          <li class=" ">
                                            <a href="promotion.php">
                                                <span class="pcoded-mtext">Student Promotion </span>
                                    
                                            </a>
                                        </li>
                                         <li class=" ">
                                            <a href="users.php">
                                                <span class="pcoded-mtext">Administrators </span>
                                    
                                            </a>
                                        </li>
                                          <li class="">
                                             <a href="create_component.php" onclick="return confirm('Only Attempt this at the end of a session, Are you Sure?');">
                                                <span class="pcoded-mtext">School Session</span>
                                            </a>
                                        </li>
                                        <li class="">
                                             <a href="settings.php">
                                                <span class="pcoded-mtext">School Settings</span>
                                            </a>
                                        </li>

                                    </ul>
                                </li>
                                
                            </ul>

                            <div class="pcoded-navigatio-lavel text-muted">LOGOUT</div>
                            <ul class="pcoded-item pcoded-left-item">
                                
                             
                                <li class="">
                                    <a href="logout.php" onclick="return confirm('Do you really Want to Log Out?');">
                                        <span class="pcoded-micon"><i class="feather icon-help-circle"></i></span>
                                        <span class="pcoded-mtext">Sign Out</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </nav>